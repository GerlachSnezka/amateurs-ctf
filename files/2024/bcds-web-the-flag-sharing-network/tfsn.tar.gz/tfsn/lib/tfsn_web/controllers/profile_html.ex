defmodule TfsnWeb.ProfileHTML do
  use TfsnWeb, :html

  embed_templates "profile_html/*"
end
