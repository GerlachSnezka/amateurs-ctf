defmodule TfsnWeb.PageHTML do
  use TfsnWeb, :html

  embed_templates "page_html/*"
end
