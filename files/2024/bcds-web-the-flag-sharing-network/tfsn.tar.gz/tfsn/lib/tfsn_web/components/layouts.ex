defmodule TfsnWeb.Layouts do
  use TfsnWeb, :html

  embed_templates "layouts/*"
end
